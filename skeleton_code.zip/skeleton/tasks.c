/***************************************************************************
 *
 *   File        : tasks.c
 *   Student Id  : <INSERT STUDENT ID HERE>
 *   Name        : <INSERT STUDENT NAME HERE>
 *
 ***************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>
#include <string.h>
#include "tasks.h"

void shockwave(const char* q2_file)
{
    printf("shockwave() - IMPLEMENT ME!\n");
}

void linalgbsys(const char* q4_file)
{
    printf("linalgbsys() - IMPLEMENT ME!\n");
}

void interp(const char* q5_file, const double xo)
{
    printf("interp() - IMPLEMENT ME!\n");
}

void waveeqn(const char* q6_file)
{
    printf("heateqn() - IMPLEMENT ME!\n");
}
