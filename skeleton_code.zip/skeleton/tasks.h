/***************************************************************************
 *
 *   File        : tasks.h
 *   Student Id  : <INSERT STUDENT ID HERE>
 *   Name        : <INSERT STUDENT NAME HERE>
 *
 ***************************************************************************/

#ifndef TASKS_H

void shockwave(const char* q2_file);

void linalgbsys(const char* q4_file);

void interp(const char* q5_file, const double xo);

void waveeqn(const char* q6_file);

#endif
